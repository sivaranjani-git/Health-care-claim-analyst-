# Power BI Dashboard — Setup Guide

Power BI Desktop is a Windows GUI application, so it can't be built headlessly — this guide
gives you everything needed to build the `.pbix` file yourself in under an hour: data connection
steps, all DAX measures, and a page-by-page layout plan.

---

## 1. Connect Your Data

1. Open **Power BI Desktop** → **Get Data** → **Text/CSV**
2. Load `data/claims_data_cleaned.csv` (the cleaned file produced by the Python notebook)
3. In Power Query Editor, confirm data types:
   - `Date_of_Service` → Date
   - `Billed_Amount`, `Allowed_Amount`, `Paid_Amount`, `Adjustment_Amount` → Decimal Number
   - `Days_in_AR` → Whole Number
4. Click **Close & Apply**

### Create a Date Table (recommended for time-intelligence)
Model view → New Table:
```
DateTable = CALENDAR(MIN(claims_data_cleaned[Date_of_Service]), MAX(claims_data_cleaned[Date_of_Service]))
```
Add columns for `Month`, `MonthName`, `Year`, then mark it as a **Date Table** and relate it to
`Date_of_Service` (one-to-many).

---

## 2. DAX Measures

Create a new **Measures table** (Modeling → New Table → name it `_Measures`) and add:

```DAX
Total Claims = COUNTROWS(claims_data_cleaned)

Total Billed Amount = SUM(claims_data_cleaned[Billed_Amount])

Total Paid Amount = SUM(claims_data_cleaned[Paid_Amount])

Total Adjustment Amount = SUM(claims_data_cleaned[Adjustment_Amount])

Collection Rate = 
DIVIDE([Total Paid Amount], [Total Billed Amount], 0)

Denied Claims = 
CALCULATE([Total Claims], claims_data_cleaned[Claim_Status] = "Denied")

Denial Rate = 
DIVIDE([Denied Claims], [Total Claims], 0)

First Pass Resolved Claims = 
CALCULATE([Total Claims], claims_data_cleaned[Claim_Status] = "Paid")

First Pass Resolution Rate = 
DIVIDE([First Pass Resolved Claims], [Total Claims], 0)

Average Days in AR = 
AVERAGE(claims_data_cleaned[Days_in_AR])

Lost Revenue (Denials) = 
CALCULATE([Total Billed Amount], claims_data_cleaned[Claim_Status] = "Denied")

Paid Claims = 
CALCULATE([Total Claims], claims_data_cleaned[Claim_Status] = "Paid")

Pending Claims = 
CALCULATE([Total Claims], claims_data_cleaned[Claim_Status] = "Pending")

MoM Collection Rate Change = 
VAR CurrentRate = [Collection Rate]
VAR PreviousRate = 
    CALCULATE([Collection Rate], DATEADD(DateTable[Date], -1, MONTH))
RETURN CurrentRate - PreviousRate
```

---

## 3. Dashboard Pages & Visual Layout

### Page 1 — Executive Summary
- KPI Cards: Total Claims, Total Billed, Total Paid, Collection Rate, Denial Rate, Avg Days in AR
- Line chart: Monthly Billed vs Paid trend
- Donut chart: Claim Status breakdown
- Slicers: Month, Payer (top of page)

### Page 2 — Claims Overview
- Table: Claim_ID, Payer, Provider, Status, Billed, Paid (detail-level, filterable)
- Bar chart: Claims by Place of Service
- Map or bar chart: Claims by State
- Slicers: Payer, Provider, State, Month

### Page 3 — Denial Analysis
- Bar chart: Top Denial Reasons (Denial_Count)
- Treemap: Denied revenue by Denial Reason
- Bar chart: Top Denied CPT Codes
- KPI Card: Denial Rate, Lost Revenue (Denials)

### Page 4 — Payer Performance
- Bar chart: Collection Rate by Payer
- Bar chart: Total Billed vs Paid by Payer
- Heat map (matrix visual with conditional formatting): Payer × Month collection rate
- Table: Payer-level KPI summary

### Page 5 — Provider Performance
- Bar chart: Total Paid by Provider
- Bar chart: Denial Rate by Provider
- Scatter chart: Avg Days in AR vs Collection Rate by Provider (bubble size = claim volume)

### Page 6 — AR Aging Analysis
- Bar chart: Claims by AR Bucket (0-30 / 31-60 / 61-90 / 90+)
- KPI Card: Average Days in AR
- Heat map: AR Bucket × Payer
- Table: Claims in 90+ bucket (worklist for follow-up)

### Page 7 — Financial Summary
- KPI Cards: Total Billed, Allowed, Paid, Adjustment
- Waterfall chart: Billed → Allowed → Paid → Adjustment
- Line chart: Monthly financial trend
- Table: Full financial breakdown by payer

---

## 4. Global Slicers (add to every page via Sync Slicers)
- Month (from DateTable)
- Insurance_Payer
- Provider
- State

Use **View → Sync Slicers** to keep filters consistent across all 7 pages.

---

## 5. Formatting Tips
- Use a consistent color palette (e.g., blue = billed, green = paid, red = denied)
- Format currency measures with `$` and thousands separators
- Format rate measures (%) with 1 decimal place
- Add tooltips with additional context (e.g., hover on a payer bar to show denial rate)

Once built, save the file as `powerbi/Healthcare_Claims_Dashboard.pbix` in this repo and add
screenshots to `images/dashboard_screenshots/` for your README/portfolio.
