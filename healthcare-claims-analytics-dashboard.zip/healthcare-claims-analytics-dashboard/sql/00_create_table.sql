-- ============================================================
-- Healthcare Claims Analytics Dashboard
-- 00_create_table.sql
-- Creates the claims table and loads data from claims_data.csv
-- Compatible with SQL Server / PostgreSQL / MySQL (minor tweaks noted)
-- ============================================================

CREATE TABLE claims (
    Claim_ID           VARCHAR(20)     PRIMARY KEY,
    Patient_ID          VARCHAR(20),
    Provider            VARCHAR(100),
    Insurance_Payer      VARCHAR(100),
    CPT_Code            VARCHAR(10),
    ICD10_Code          VARCHAR(15),
    Date_of_Service      DATE,
    Billed_Amount        DECIMAL(12,2),
    Allowed_Amount        DECIMAL(12,2),
    Paid_Amount          DECIMAL(12,2),
    Adjustment_Amount      DECIMAL(12,2),
    Denial_Code          VARCHAR(10),
    Denial_Reason         VARCHAR(200),
    Claim_Status          VARCHAR(20),
    Days_in_AR           INT,
    Place_of_Service       VARCHAR(50),
    State               VARCHAR(5)
);

-- ---------------------------------------------------------
-- Load data (choose the syntax that matches your DB engine)
-- ---------------------------------------------------------

-- SQL Server (BULK INSERT):
-- BULK INSERT claims
-- FROM 'C:\path\to\claims_data.csv'
-- WITH (FORMAT = 'CSV', FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');

-- PostgreSQL:
-- COPY claims FROM '/path/to/claims_data.csv' DELIMITER ',' CSV HEADER;

-- MySQL:
-- LOAD DATA LOCAL INFILE '/path/to/claims_data.csv'
-- INTO TABLE claims
-- FIELDS TERMINATED BY ',' ENCLOSED BY '"'
-- LINES TERMINATED BY '\n'
-- IGNORE 1 ROWS;
