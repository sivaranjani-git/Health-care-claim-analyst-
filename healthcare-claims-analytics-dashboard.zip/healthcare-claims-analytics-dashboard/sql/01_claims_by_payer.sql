-- ============================================================
-- 01_claims_by_payer.sql
-- Total claims, billed, paid, and collection rate by payer
-- ============================================================

SELECT
    Insurance_Payer,
    COUNT(*)                                   AS Total_Claims,
    SUM(Billed_Amount)                         AS Total_Billed,
    SUM(Paid_Amount)                           AS Total_Paid,
    ROUND(SUM(Paid_Amount) * 100.0 / NULLIF(SUM(Billed_Amount), 0), 2) AS Collection_Rate_Pct,
    SUM(CASE WHEN Claim_Status = 'Denied' THEN 1 ELSE 0 END)          AS Denied_Claims,
    ROUND(SUM(CASE WHEN Claim_Status = 'Denied' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*), 2)                          AS Denial_Rate_Pct
FROM claims
GROUP BY Insurance_Payer
ORDER BY Total_Billed DESC;
