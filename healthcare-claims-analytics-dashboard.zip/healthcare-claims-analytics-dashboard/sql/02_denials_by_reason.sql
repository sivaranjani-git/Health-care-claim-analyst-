-- ============================================================
-- 02_denials_by_reason.sql
-- Denial count, lost revenue, and % share by denial reason
-- ============================================================

SELECT
    Denial_Code,
    Denial_Reason,
    COUNT(*)                                       AS Denial_Count,
    SUM(Billed_Amount)                             AS Lost_Revenue,
    ROUND(COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM claims WHERE Claim_Status IN ('Denied','Partially Paid')), 2)
                                                    AS Pct_of_All_Denials
FROM claims
WHERE Claim_Status IN ('Denied', 'Partially Paid')
  AND Denial_Code <> ''
GROUP BY Denial_Code, Denial_Reason
ORDER BY Denial_Count DESC;
