-- ============================================================
-- 03_monthly_payment_trend.sql
-- Monthly billed vs paid amounts and collection rate trend
-- ============================================================

SELECT
    FORMAT(Date_of_Service, 'yyyy-MM')             AS Claim_Month,   -- SQL Server syntax
    -- For PostgreSQL use: TO_CHAR(Date_of_Service, 'YYYY-MM') AS Claim_Month
    -- For MySQL use:      DATE_FORMAT(Date_of_Service, '%Y-%m') AS Claim_Month
    COUNT(*)                                       AS Total_Claims,
    SUM(Billed_Amount)                             AS Total_Billed,
    SUM(Paid_Amount)                               AS Total_Paid,
    ROUND(SUM(Paid_Amount) * 100.0 / NULLIF(SUM(Billed_Amount), 0), 2) AS Collection_Rate_Pct
FROM claims
GROUP BY FORMAT(Date_of_Service, 'yyyy-MM')
ORDER BY Claim_Month;
