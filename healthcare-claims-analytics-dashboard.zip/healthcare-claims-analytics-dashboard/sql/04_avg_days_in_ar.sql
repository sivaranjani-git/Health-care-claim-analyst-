-- ============================================================
-- 04_avg_days_in_ar.sql
-- Average Days in AR overall, by payer, and by AR aging bucket
-- ============================================================

-- Overall average
SELECT ROUND(AVG(Days_in_AR), 1) AS Avg_Days_in_AR
FROM claims
WHERE Days_in_AR IS NOT NULL;

-- By payer
SELECT
    Insurance_Payer,
    ROUND(AVG(Days_in_AR), 1) AS Avg_Days_in_AR,
    COUNT(*)                  AS Total_Claims
FROM claims
WHERE Days_in_AR IS NOT NULL
GROUP BY Insurance_Payer
ORDER BY Avg_Days_in_AR DESC;

-- AR Aging buckets
SELECT
    CASE
        WHEN Days_in_AR <= 30 THEN '0-30 Days'
        WHEN Days_in_AR BETWEEN 31 AND 60 THEN '31-60 Days'
        WHEN Days_in_AR BETWEEN 61 AND 90 THEN '61-90 Days'
        ELSE '90+ Days'
    END                         AS AR_Bucket,
    COUNT(*)                    AS Claim_Count,
    SUM(Billed_Amount)          AS Billed_Amount_In_Bucket
FROM claims
WHERE Days_in_AR IS NOT NULL
GROUP BY
    CASE
        WHEN Days_in_AR <= 30 THEN '0-30 Days'
        WHEN Days_in_AR BETWEEN 31 AND 60 THEN '31-60 Days'
        WHEN Days_in_AR BETWEEN 61 AND 90 THEN '61-90 Days'
        ELSE '90+ Days'
    END
ORDER BY AR_Bucket;
