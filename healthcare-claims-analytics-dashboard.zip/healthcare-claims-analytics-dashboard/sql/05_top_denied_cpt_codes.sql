-- ============================================================
-- 05_top_denied_cpt_codes.sql
-- CPT codes with the highest denial counts and associated lost revenue
-- ============================================================

SELECT
    CPT_Code,
    COUNT(*)                                              AS Total_Claims,
    SUM(CASE WHEN Claim_Status = 'Denied' THEN 1 ELSE 0 END)          AS Denied_Claims,
    ROUND(SUM(CASE WHEN Claim_Status = 'Denied' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*), 2)                                    AS Denial_Rate_Pct,
    SUM(CASE WHEN Claim_Status = 'Denied' THEN Billed_Amount ELSE 0 END)   AS Denied_Revenue
FROM claims
GROUP BY CPT_Code
HAVING SUM(CASE WHEN Claim_Status = 'Denied' THEN 1 ELSE 0 END) > 0
ORDER BY Denied_Claims DESC;
