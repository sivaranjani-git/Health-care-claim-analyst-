-- ============================================================
-- 06_provider_wise_collections.sql
-- Provider-level billed, paid, collection rate, and denial rate
-- ============================================================

SELECT
    Provider,
    COUNT(*)                                       AS Total_Claims,
    SUM(Billed_Amount)                             AS Total_Billed,
    SUM(Paid_Amount)                               AS Total_Paid,
    ROUND(SUM(Paid_Amount) * 100.0 / NULLIF(SUM(Billed_Amount), 0), 2) AS Collection_Rate_Pct,
    SUM(CASE WHEN Claim_Status = 'Denied' THEN 1 ELSE 0 END)          AS Denied_Claims,
    ROUND(SUM(CASE WHEN Claim_Status = 'Denied' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*), 2)                              AS Denial_Rate_Pct,
    ROUND(AVG(Days_in_AR), 1)                       AS Avg_Days_in_AR
FROM claims
GROUP BY Provider
ORDER BY Total_Paid DESC;
